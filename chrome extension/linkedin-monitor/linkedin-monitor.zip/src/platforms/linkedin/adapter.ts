/**
 * ============================================================================
 * File Name: adapter.ts
 * Module: LinkedIn platform
 * Purpose: Serve as the LinkedIn content-script entry point.
 * Responsibilities: Start observation and forward parsed Leads to the background coordinator.
 * Called By: Chrome content-script runtime through manifest.json.
 * Calls: observer.ts and Chrome Runtime API.
 * Receives: Parsed Leads from observer.ts.
 * Returns: Nothing.
 * Dependencies: observer.ts, messages.ts, logger.ts, Chrome Runtime API.
 * Connected Files: manifest.json → adapter.ts → observer.ts → service-worker.ts.
 * Project Phase: LinkedIn Adapter.
 * Notes: Keyword matching, storage, and notifications intentionally remain outside this platform layer.
 * ============================================================================
 */

import type { LeadDetectedMessage, SearchScanCompleteMessage } from "../../types/messages";
import { logger } from "../../utils/logger";
import { observeLinkedInPosts } from "./observer";
import { scanLinkedInPosts } from "./scanner";
import { parseLinkedInPost } from "./parser";

function forwardLeadToBackground(lead: LeadDetectedMessage["lead"]): void {
  const message: LeadDetectedMessage = { type: "LEAD_DETECTED", lead };
  chrome.runtime.sendMessage(message, () => {
    const error = chrome.runtime.lastError?.message;
    if (error) logger.debug("Lead was not delivered to background", { error });
  });
}

/**
 * Purpose: Scroll the search results page to trigger lazy loading, scan the posts, and notify completion.
 * Called By: initializeLinkedInAdapter when monitor=true parameter is present.
 * Calls: scanLinkedInPosts, parseLinkedInPost, forwardLeadToBackground, and Chrome Runtime sendMessage.
 * Parameters: None.
 * Returns: Promise resolving after scan complete.
 * Dependencies: LinkedIn scanner, parser, and Chrome Runtime API.
 */
async function runAutoMonitorScan(): Promise<void> {
  logger.info("Auto-monitor search tab active. Waiting for posts to load...");
  
  // Wait 4 seconds for initial page results to load
  await new Promise((resolve) => setTimeout(resolve, 4000));
  
  // Scroll down to trigger lazy loading of additional search results
  window.scrollTo(0, document.body.scrollHeight);
  
  // Wait another 3 seconds for loaded items to mount
  await new Promise((resolve) => setTimeout(resolve, 3000));
  
  try {
    const rawPosts = scanLinkedInPosts(document);
    logger.info(`Auto-monitor scan complete. Found ${rawPosts.length} posts.`);
    
    const leads = rawPosts.map(parseLinkedInPost);
    leads.forEach(forwardLeadToBackground);
  } catch (error) {
    logger.error("Error during auto-monitor search scan", { error });
  } finally {
    // Notify service worker that we're done so the tab can be closed
    const completeMessage: SearchScanCompleteMessage = { type: "SEARCH_SCAN_COMPLETE" };
    chrome.runtime.sendMessage(completeMessage);
  }
}

/**
 * Purpose: Initialize LinkedIn monitoring or auto-scan based on page context.
 * Called By: This content script entry point.
 * Calls: runAutoMonitorScan or observeLinkedInPosts.
 * Parameters: None.
 * Returns: Nothing.
 * Dependencies: LinkedIn observer, runAutoMonitorScan, and logger.
 */
export function initializeLinkedInAdapter(): void {
  const isMonitorTab = window.location.search.includes("monitor=true");
  
  if (isMonitorTab) {
    void runAutoMonitorScan();
  } else {
    observeLinkedInPosts(forwardLeadToBackground);
    logger.info("LinkedIn monitoring initialized");
  }
}

if (document.body) initializeLinkedInAdapter();
else document.addEventListener("DOMContentLoaded", initializeLinkedInAdapter, { once: true });
