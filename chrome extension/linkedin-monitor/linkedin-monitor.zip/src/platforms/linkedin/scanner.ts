/**
 * ============================================================================
 * File Name: scanner.ts
 * Module: LinkedIn platform
 * Purpose: Locate newly visible LinkedIn feed posts and extract raw platform fields.
 * Responsibilities: Perform all LinkedIn DOM reads and return raw post data only once.
 * Called By: observer.ts.
 * Calls: Native DOM selector APIs.
 * Receives: A DOM root containing potential LinkedIn content.
 * Returns: Raw LinkedIn post data for parser.ts.
 * Dependencies: helper.ts.
 * Connected Files: observer.ts → scanner.ts → parser.ts.
 * Project Phase: LinkedIn Scanner.
 * Notes: Selectors are deliberately isolated here because LinkedIn markup changes frequently.
 * ============================================================================
 */

import { normalizeText } from "../../utils/helper";

/** Raw data collected from LinkedIn DOM before conversion to a shared Lead. */
export interface RawLinkedInPost {
  sourceUrl: string;
  authorName: string;
  authorProfileUrl?: string;
  content: string;
  publishedAt?: string;
  timeText?: string;
}

const POST_SELECTORS = "article, [data-urn*='activity'], .feed-shared-update-v2";
const AUTHOR_SELECTORS = ".update-components-actor__name, .feed-shared-actor__name, [data-test-id='actor-name']";
const CONTENT_SELECTORS = ".update-components-text, .feed-shared-update-v2__description, [data-test-id='main-feed-activity-card__commentary']";

function getUnscannedPostElements(root: ParentNode): HTMLElement[] {
  const candidates = root.querySelectorAll<HTMLElement>(POST_SELECTORS);
  return [...candidates].filter((element) => element.dataset.linkedinMonitorScanned !== "true");
}

function readPostElement(element: HTMLElement): RawLinkedInPost {
  const authorLink = element.querySelector<HTMLAnchorElement>("a[href*='/in/']");
  const authorName = normalizeText(element.querySelector(AUTHOR_SELECTORS)?.textContent) || "LinkedIn member";
  const content = normalizeText(element.querySelector(CONTENT_SELECTORS)?.textContent) || normalizeText(element.innerText);
  const postUrl = element.querySelector<HTMLAnchorElement>("a[href*='/feed/update/'], a[href*='/posts/']")?.href;
  
  const timeElement = element.querySelector("time");
  const publishedAt = timeElement?.getAttribute("datetime") ?? undefined;
  const timeText = timeElement ? normalizeText(timeElement.textContent) : undefined;

  return {
    sourceUrl: postUrl ?? window.location.href,
    authorName,
    authorProfileUrl: authorLink?.href,
    content,
    publishedAt,
    timeText,
  };
}

/**
 * Purpose: Read each unprocessed LinkedIn post once to reduce duplicate DOM work.
 * Called By: observer.ts.
 * Calls: DOM selectors and readPostElement.
 * Parameters: The document or mutation subtree to scan.
 * Returns: Raw LinkedIn post records with no business decision applied.
 * Dependencies: LinkedIn DOM and normalizeText.
 * Side Effects: Marks scanned post elements to avoid repeat processing during infinite scroll.
 * Next Flow: Every raw record is passed to parser.ts by observer.ts.
 */
export function scanLinkedInPosts(root: ParentNode = document): RawLinkedInPost[] {
  return getUnscannedPostElements(root).map((element) => {
    element.dataset.linkedinMonitorScanned = "true";
    return readPostElement(element);
  }).filter((post) => post.content.length > 0);
}
